This is just used to edit the custom fields c_Risks, c_TeamCommits and c_Dependencies. Only for development and debugging purposes
