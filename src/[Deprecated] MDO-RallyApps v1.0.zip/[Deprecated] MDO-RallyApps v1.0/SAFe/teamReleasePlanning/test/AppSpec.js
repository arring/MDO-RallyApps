describe('App', function() {
    it('should not fail', function() {
        expect(true).toBe(true);
    });
});