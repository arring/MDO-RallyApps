If your going to use the portfoliohierarchy for another reason (Story-Feature mapping)
make sure you build with sm-rab (https://www.npmjs.com/package/sm-rab) and use the
sm-app.html output file. That way you can get drag-and-drop functionality.
